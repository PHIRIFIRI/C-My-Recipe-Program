﻿//The following is an outer class to sore our values of the recipe 
using System.Runtime.CompilerServices;

class Recipe{
    //i have declared variables in array listing to store values
    public List<Ingredient> Ingredients { get; set; }
    public List<string> Steps { get; set; }

    public Recipe()//The following method will store values in array listing for ingridients and steps
    {
        Ingredients = new List<Ingredient>();
        Steps = new List<string>();
    }

    public Recipe(List<string> steps)//The method for creating a step to add values
    {
        Steps = steps;
    }

    //The following method will add ingridients with name,quantity and unit
    public void AddIngredient(string name, double quantity, string unit)
    {
        Ingredients.Add(new Ingredient(name, quantity, unit));
    }

    public void AddStep(string description)// The method for creating steps and adding values into it 
    {
        Steps.Add(description);
    }

    public void Print()//The following method is created to print our stored values
    {
        Console.WriteLine("Ingredients:");
        foreach (Ingredient ingredient in Ingredients)
        {
            Console.WriteLine($"{ingredient.Name}: {ingredient.Quantity} {ingredient.Unit}");
        }

        Console.WriteLine("\nSteps:");
        for (int i = 0; i < Steps.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {Steps[i]}");
        }
    }

    public void Scale(double factor)//The following method is for scaling our recipe quantities 
    {
        foreach (Ingredient ingredient in Ingredients)
        {
            ingredient.Quantity *= factor;
        }
    }

    public void ResetQuantities()//The following method is for reseting quantity in our recipe
    {
        foreach (Ingredient ingredient in Ingredients)
        {
            ingredient.Quantity = ingredient.OriginalQuantity;
        }
    }

    public void Clear()//The following ,ethod is for clearing our recipe
    {
        Ingredients.Clear();
        Steps.Clear();
    }
}

class Ingredient //The following class is for get and set values to be displayed in our main program
{
    public string Name { get; set; }
    public double Quantity { get; set; }
    public double OriginalQuantity { get; set; }
    public string Unit { get; set; }

    public Ingredient(string name, double quantity, string unit)
    {
        Name = name;
        Quantity = quantity;
        OriginalQuantity = quantity;
        Unit = unit;
    }
}
//The end of our outter classes


class Program //This is the beginning of our main program 
{
    static void Main(string[] args)
    {
        Recipe recipe = new Recipe();//Recipe class instantiation

        //The welcome message for the prgram with instructions
        Console.WriteLine("******************************************************************");
        Console.WriteLine("*********************** W E L C O M E!!!...************************");
        Console.WriteLine("******************************************************************");
        Console.WriteLine("Please follow the instructions & Create your own meal from start..");
        Console.WriteLine("******************************************************************");
        //The following code will ask the user for input to store values
        Console.Write("Please enter the number of ingredients : \n");

        int numIngredients = int.Parse(Console.ReadLine());

        for (int i = 0; i < numIngredients; i++)
        {
            //this prompts will ask user to input and increments for input needed
            //prompts for ingredients values
            Console.Write($"Please enter the name of ingredient {i + 1} : \n");
            string name = Console.ReadLine();

            Console.Write($"Please enter the quantity of ingredient {i + 1} : \n");
            double q = double.Parse(Console.ReadLine());
            double quantity = q;

            Console.Write($"Please enter the unit of measurement of ingredient {i + 1} : \n");
            string unit = Console.ReadLine();

            recipe.AddIngredient(name, quantity, unit);
        }
        //prompts for steps inputs
        Console.Write("Please enter the number of steps : \n");
        int numSteps = int.Parse(Console.ReadLine());

        for (int i = 0; i < numSteps; i++)
        {
            Console.Write($"Please enter the description of step {i + 1}: \n");
            string description = Console.ReadLine();

            recipe.AddStep(description);
        }

        Console.WriteLine("\n YourRecipe : \n");
        //The following will display our final recipe
        recipe.Print();
        //The while loop will display our mini menu with options to choose in order to manipulate the recipe
        while (true)
        {
            Console.Write("\nPlease enter the word 'scale' to scale \n+" +
                " 'reset' to reset \n+" +
                " 'clear' to clear \n+" +
                " or 'exit' to exit the program): \n");
            string word = Console.ReadLine();
//The switch loop have been used so that we can choose our desired option
            switch (word)
            {
                case "scale":
                    Console.Write("Please enter the scale factor (0.5, 2, or 3): ");
                    double factor = double.Parse(Console.ReadLine());
                    recipe.Scale(factor);
                    recipe.Print();
                    break;

                case "reset":
                    recipe.ResetQuantities();
                    recipe.Print();
                    break;

                case "clear":
                    recipe.Clear();
                    Console.WriteLine("\nThe recipe cleared.");
                    break;

                case "exit":
                    Console.WriteLine("Good Bye!!!");
                    Environment.Exit(0);
                    break;

                default:
                    Console.WriteLine("\nInvalid word. Try again.");
                    break;
                    //This is the end of the program
            }
        }
    }
}

